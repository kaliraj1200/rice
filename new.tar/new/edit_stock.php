<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM stock WHERE id=$id");
    $row = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    $stmt = $conn->prepare("UPDATE stock SET name=?, quantity=?, price=? WHERE id=?");
    $stmt->bind_param("sidi", $name, $quantity, $price, $id);
    
    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Stock</title>
</head><link rel="stylesheet" href="styles.css">
<body>

<h2>Edit Stock</h2>
<form method="post">
    <label>Rice Name:</label>
    <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
    
    <label>Quantity (kg):</label>
    <input type="number" name="quantity" value="<?php echo $row['quantity']; ?>" required>

    <label>Price (₹ per kg):</label>
    <input type="text" name="price" value="<?php echo $row['price']; ?>" required>

    <button type="submit">Update Stock</button>
</form>

</body>
</html>
