<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM stock WHERE id=$id");
    header("Location: admin_dashboard.php");
}
?>
