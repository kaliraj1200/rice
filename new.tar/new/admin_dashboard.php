<?php
include 'config.php';

// Fetch stock details
$result = $conn->query("SELECT * FROM stock ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rice Shop - Stock Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<h2>Stock Dashboard</h2>
<a href="add_stock.php" class="btn">+ Add Stock</a>

<table>
    <tr>
        <th>Name</th>
        <th>Quantity (kg)</th>
        <th>Price (₹ per kg)</th>
        <th>Added On</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td>₹<?php echo $row['price']; ?></td>
            <td><?php echo $row['added_on']; ?></td>
            <td>
                <a href="edit_stock.php?id=<?php echo $row['id']; ?>">Edit</a> | 
                <a href="delete_stock.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this item?')">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
