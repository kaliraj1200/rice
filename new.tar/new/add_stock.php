<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    $stmt = $conn->prepare("INSERT INTO stock (name, quantity, price) VALUES (?, ?, ?)");
    $stmt->bind_param("sid", $name, $quantity, $price);
    
    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Stock</title>
</head>
<link rel="stylesheet" href="styles.css">
<body>

<h2>Add New Stock</h2>
<form method="post">
    <label>Rice Name:</label>
    <input type="text" name="name" required>
    
    <label>Quantity (kg):</label>
    <input type="number" name="quantity" required>

    <label>Price (₹ per kg):</label>
    <input type="text" name="price" required>

    <button type="submit">Add Stock</button>
</form>

</body>
</html>
