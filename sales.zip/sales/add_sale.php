<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<pre>";
    print_r($_POST); // Debugging: Print form data
    echo "</pre>";

    // Ensure all fields are present
    if (empty($_POST['id']) || empty($_POST['quantity']) || empty($_POST['sale_price'])) {
        die("Error: Please fill in all fields before submitting.");
    }

    $id = intval($_POST['id']);
    $quantity = intval($_POST['quantity']);
    $sale_price = floatval($_POST['sale_price']);

    if ($quantity <= 0 || $sale_price <= 0) {
        die("Error: Quantity and price must be positive values!");
    }

    // Check stock availability
    $checkStock = $conn->prepare("SELECT quantity FROM stock WHERE id = ?");
    $checkStock->bind_param("i", $id);
    $checkStock->execute();
    $result = $checkStock->get_result();

    if ($result->num_rows === 0) {
        die("Error: Selected rice does not exist in stock!");
    }

    $stock = $result->fetch_assoc()['quantity'];

    if ($stock >= $quantity) {
        // Insert sale
        $stmt = $conn->prepare("INSERT INTO sales (stock_id, quantity, sale_price) VALUES (?, ?, ?)");
        $stmt->bind_param("iid", $id, $quantity, $sale_price);

        if ($stmt->execute()) {
            // Update stock
            $updateStock = $conn->prepare("UPDATE stock SET quantity = quantity - ? WHERE id = ?");
            $updateStock->bind_param("ii", $quantity, $id);
            $updateStock->execute();

            header("Location: sales_report.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        die("Error: Not enough stock available!");
    }
}

// Fetch all stock items
$stockItems = $conn->query("SELECT * FROM stock");

// Prevent form submission if no stock is available
if ($stockItems->num_rows == 0) {
    die("Error: No stock available! Please add stock first.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Sale</title>
</head>
<body>

<h2>Record New Sale</h2>
<form method="post">
    <label>Rice Name:</label>
    <select name="id" required>
        <option value="" disabled selected>Select Rice</option>
        <?php while ($item = $stockItems->fetch_assoc()): ?>
            <option value="<?php echo $item['id']; ?>" 
                <?php echo (isset($_POST['id']) && $_POST['id'] == $item['id']) ? "selected" : ""; ?>>
                <?php echo $item['name']; ?> (Available: <?php echo $item['quantity']; ?> kg)
            </option>
        <?php endwhile; ?>
    </select>

    <label>Quantity Sold (kg):</label>
    <input type="number" name="quantity" required min="1" value="<?php echo isset($_POST['quantity']) ? $_POST['quantity'] : ''; ?>">

    <label>Sale Price (₹ per kg):</label>
    <input type="number" name="sale_price" required step="0.01" min="1" value="<?php echo isset($_POST['sale_price']) ? $_POST['sale_price'] : ''; ?>">

    <button type="submit">Add Sale</button>
</form>

</body>
</html>
