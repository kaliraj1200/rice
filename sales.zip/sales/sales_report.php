<?php
include 'config.php';

// Fetch all sales data
$query = "SELECT sales.*, stock.name FROM sales 
          JOIN stock ON sales.stock_id = stock.id 
          ORDER BY sales.sale_date DESC";
$result = $conn->query($query);

// Calculate total revenue
$totalRevenueQuery = "SELECT SUM(quantity * sale_price) AS total_revenue FROM sales";
$totalRevenueResult = $conn->query($totalRevenueQuery);
$totalRevenue = $totalRevenueResult->fetch_assoc()['total_revenue'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<h2>Sales Report</h2>
<p><strong>Total Revenue:</strong> ₹<?php echo number_format($totalRevenue, 2); ?></p>

<table>
    <tr>
        <th>Rice Name</th>
        <th>Quantity Sold (kg)</th>
        <th>Sale Price (₹ per kg)</th>
        <th>Total Sale (₹)</th>
        <th>Sale Date</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td>₹<?php echo $row['sale_price']; ?></td>
            <td>₹<?php echo number_format($row['quantity'] * $row['sale_price'], 2); ?></td>
            <td><?php echo $row['sale_date']; ?></td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
