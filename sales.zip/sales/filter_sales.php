<?php
include 'config.php';

$from_date = isset($_POST['from_date']) ? $_POST['from_date'] : date('Y-m-01');
$to_date = isset($_POST['to_date']) ? $_POST['to_date'] : date('Y-m-t');

$query = "SELECT sales.*, stock.name FROM sales 
          JOIN stock ON sales.stock_id = stock.id 
          WHERE DATE(sales.sale_date) BETWEEN '$from_date' AND '$to_date'
          ORDER BY sales.sale_date DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Filter Sales</title>
</head>
<body>

<h2>Filter Sales by Date</h2>
<form method="post">
    <label>From Date:</label>
    <input type="date" name="from_date" value="<?php echo $from_date; ?>" required>

    <label>To Date:</label>
    <input type="date" name="to_date" value="<?php echo $to_date; ?>" required>

    <button type="submit">Filter</button>
</form>

<table>
    <tr>
        <th>Rice Name</th>
        <th>Quantity Sold (kg)</th>
        <th>Sale Price (₹ per kg)</th>
        <th>Total Sale (₹)</th>
        <th>Sale Date</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td>₹<?php echo $row['sale_price']; ?></td>
            <td>₹<?php echo number_format($row['quantity'] * $row['sale_price'], 2); ?></td>
            <td><?php echo $row['sale_date']; ?></td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
