<?php

@include 'config.php';
session_start();
if (isset($_POST['login'])) {

    $U_mail = $_POST['username'];
    $U_pass = $_POST['userpass'];

    $sql = "SELECT * FROM `userdata` WHERE user_email = '$U_mail' and user_ucpass = '$U_pass'";

    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row["user_email"] == $U_mail && $row["user_ucpass"] == $U_pass) {
        header('location:admin.php');
    } else {
        echo '<script>alert("Sorry, your credentials are not valid, Please try again.")</script>';

    }
}
?>




<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Registration Form using HTML & CSS | LITEMAP</title>
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <h1>login</h1>
        <form action="#" method="post">
            <div class="form-group">
                <input type="email" placeholder="Enter Your email" name="username">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Enter Your pass" name="userpass">
            </div>


            <div class="form-group">
                <input type="submit" name="login">
            </div>
        </form>
    </div>
</body>

</html>