<?php
@include 'config.php';
if (isset($_POST['regi'])) {
    $U_Name = $_POST['uname'];
    $U_Email = $_POST['uemail'];

    $U_Cpass = $_POST['ucpass'];
    $U_Phone = $_POST['uphone'];
    // $p_Image = $_FILES['p_Image']['name'];
    // $p_Image_tmp_name = $_FILES['p_Image']['tmp_name'];
    // $p_Image_folder = 'Images_upload/' . $p_Image;


    $insert_query = mysqli_query($conn, "INSERT INTO userdata (user_name,user_email,user_ucpass,user_mobile) VALUES
('$U_Name','$U_Email','$U_Cpass','$U_Phone')") or die('query failed');

    if ($insert_query) {
        // move_uploaded_file($p_Image_tmp_name, $p_Image_folder);
        echo '<script>alert("User added Successfully")</script>';
    }


}

?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Registration Form using HTML & CSS | LITEMAP</title>
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <h1>Registration</h1>
        <form action="" method="POST" enctype="multipart/form-data">

            <input type="text" name="uname" placeholder="Enter Your Name" required>

            <input type="email" name="uemail" placeholder="Enter Your Email" required>



            <!-- <div class="form-group">
                <input type="password" placeholder="Create Password" name="upass" required>
            </div> -->

            <input type="password" name="ucpass" placeholder="Cofirm Password" required>
            <input type="number" name="uphone" placeholder="Phone Number" required>

            <div class="policy">
                <input type="checkbox" id="check" required>
                <label for="check">I accept all terms & conditions</label>
            </div>

            <input type="submit" value="Register" name="regi">
            <div class="link-to"><span>Alredy have an account? <a href="Login_User.php">Login</a></span></div>
        </form>
    </div>
</body>

</html>