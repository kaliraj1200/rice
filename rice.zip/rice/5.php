<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rice_shop";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["message" => "Connection failed: " . $conn->connect_error]));
}

// Fetch Product Data
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $productId = intval($_GET['id']);
    $sql = "SELECT * FROM products WHERE id = $productId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode(["message" => "Product not found"]);
    }
}

// Handle Add to Cart Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data['productId']) && isset($data['quantity'])) {
        $productId = intval($data['productId']);
        $quantity = intval($data['quantity']);

        // Validate Product Availability
        $sql = "SELECT stock FROM products WHERE id = $productId";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        if ($row && $row['stock'] >= $quantity) {
            echo json_encode(["message" => "Product added to cart"]);
        } else {
            echo json_encode(["message" => "Not enough stock"]);
        }
    } else {
        echo json_encode(["message" => "Invalid request"]);
    }
}

$conn->close();
?>