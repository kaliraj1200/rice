document.addEventListener("DOMContentLoaded", function () {
    fetch('api.php?id=1')
        .then(response => response.json())
        .then(product => {
            document.getElementById('productImage').src = "images/" + product.image;
            document.getElementById('productName').textContent = product.name;
            document.getElementById('productDescription').textContent = product.description;
            document.getElementById('productPrice').textContent = $${product.price} per kg;
            document.getElementById('stockStatus').textContent = product.stock > 0 ? "In Stock" : "Out of Stock";
            document.getElementById('stockStatus').classList.add(product.stock > 0 ? "text-success" : "text-danger");
        })
        .catch(error => console.error('Error:', error));
});

function addToCart() {
    let productId = 1;
    let quantity = document.getElementById('quantity').value;

    fetch('api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, quantity })
    })
    .then(response => response.json())
    .then(data => alert(data.message))
    .catch(error => console.error('Error:', error));
}