<?php
@include 'config.php';


if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_qurey = mysqli_query($conn, "DELETE FROM `userdata` WHERE id =$delete_id");
    if ($delete_qurey) {
        // header('location:Products.php');
        echo '<script>alert("Product Deleted Successfully")</script>';
    } else {
        // header('location:Products.php');
        echo '<script>alert("Could Not Be Deleted Successfully")</script>';
    }
}



//

//     $result = $conn->query("SELECT * FROM products WHERE id=$id") or die($conn->error);
//     if ($result->num_rows) {
//         $row = $result->fetch_array();
//         $name = $row['name'];
//         $price = $row['price'];
//         $description = $row['description'];
//         $image = $row['image'];
//     }
// }


?>








<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Barlow' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

    <title>Products</title>
    <link rel="icon" type="image/x-icon" href="Image/avartar.png">
    <link rel="stylesheet" href="CSS/style.css" type="text/css">
</head>

<body>


    <section id="sideMenu">

        <div class="sideNav">
            <div class="brand">
                <h3>
                    <Span><img src="Image/logo.png" alt="">Vel Rice Shop</Span>

                </h3>
            </div>

            <a href="admin.php"><i class="fa fa-solid fa-house"></i>Dashboard</a>
            <a href="Products.php"><i class="fa-solid fa-pen-to-square"></i>Products</a>
            <a href="salesReport.php"><i class="fa-solid fa-chart-column"></i>Analytics</a>
            <a href="#Customer"><i class="fa-solid fa-users"></i>Custormer</a>
            <a href="#Purchase" class="drop-down"><i class="fa-solid fa-clipboard"></i>Purchase Details</a>
            <div class="drop-down-container ">
                <a href="add.html"><i class="fa-solid fa-square-plus"></i>Add Product</a>
            </div>
            <a href=""><i class="fa fa-solid fa-house"></i>sample</a>
            <a href=""></a>


        </div>
    </section>

    <section id="main">
        <div class="navBar">
            <div class="search-div">

                <input class="Search " type="search" placeholder="Search here">
                <button type="submit"><i class="fa fa-search"></i></button>


                <div class="userProfile">

                    <h3>Hai, Admin <span>Ajith</span></h3>
                    <img src="Image/avartar.png" alt="">


                </div>
            </div>
        </div>
    </section>



    <!-- <div class="addProductButton">
        <a href="addProduct.php"><i class="fa-solid fa-square-plus"></i>Add New Product</a>
    </div> -->


    <section class="product-data">


        <table>
            <thead>
                <th>Id</th>
                <!-- <th>Product Image</th> -->
                <th>Customer Name</th>
                <th>Customer Email</th>
                <th>Customer Phone</th>
                <!-- <th>Price</th> -->
                <th>action</th>
            </thead>

            <tbody>
                <?php
                $select_products = mysqli_query($conn, "SELECT * FROM `userdata`");
                if (mysqli_num_rows($select_products) > 0) {
                    while ($row = mysqli_fetch_assoc($select_products)) {

                        ?>

                        <tr>


                            <td><?php echo $row['Id'] ?></td>
                            <!-- <td><img src="Images_upload/<?php echo $row['ProductImage']; ?>" height="100px" width="100px"
                                    alt="">
                            </td> -->

                            <td><?php echo $row['user_name'] ?></td>
                            <td><?php echo $row['user_email'] ?></td>
                            <td><?php echo $row['user_mobile'] ?> Kg</td>
                            <td>
                                <a href="customer.php?delete=<?php echo $row['Id']; ?>" class="delete-btn"
                                    onclick="return confirm('Are you sure delete this ?');"><i
                                        class="fas fa-trash"></i>Delete</a>
                            </td>
                        </tr>

                        <?php

                    }
                    ;
                } else {
                    echo "<span>No Product Added</span>";
                }
                ?>
            </tbody>
        </table>

    </section>


</body>

</html>