document.addEventListener("DOMContentLoaded", function () {
    fetch('api.php?action=getCart')
        .then(response => response.json())
        .then(cart => {
            let cartTable = document.getElementById('cartItems');
            let cartTotal = 0;

            cart.forEach(item => {
                let row = cartTable.insertRow();
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>$${item.price}</td>
                    <td>${item.quantity}</td>
                    <td>$${(item.price * item.quantity).toFixed(2)}</td>
                    <td><button class="btn btn-danger" onclick="removeFromCart(${item.id})">Remove</button></td>
                `;
                cartTotal += item.price * item.quantity;
            });

            document.getElementById('cartTotal').textContent = cartTotal.toFixed(2);
        });
});

function removeFromCart(productId) {
    fetch('api.php?action=removeFromCart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId })
    })
    .then(response => response.json())
    .then(data => location.reload());
}