<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rice_shop";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["message" => "Connection failed: " . $conn->connect_error]));
}

$action = $_GET['action'] ?? '';

if ($action === 'getCart') {
    $sql = "SELECT cart.id, products.name, products.price, cart.quantity 
            FROM cart 
            JOIN products ON cart.product_id = products.id";
    $result = $conn->query($sql);
    
    $cart = [];
    while ($row = $result->fetch_assoc()) {
        $cart[] = $row;
    }
    echo json_encode($cart);
}

if ($action === 'removeFromCart') {
    $data = json_decode(file_get_contents("php://input"), true);
    $productId = intval($data['productId']);
    
    $sql = "DELETE FROM cart WHERE product_id = $productId LIMIT 1";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["message" => "Item removed"]);
    } else {
        echo json_encode(["message" => "Error removing item"]);
    }
}

$conn->close();
?>